
// Service deleted as per request to remove Gemini integration.
